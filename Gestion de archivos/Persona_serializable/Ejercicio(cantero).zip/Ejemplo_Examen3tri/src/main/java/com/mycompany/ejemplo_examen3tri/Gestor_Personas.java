/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejemplo_examen3tri;

import java.io.*;
import java.util.*;

/**
 *
 * @author Miguel Cantero
 */
public class Gestor_Personas {

    Scanner entrada = new Scanner(System.in);
    private Map<Integer, Persona> personas = new HashMap<>(); //Mapa que contendrá a las personas y el ID como clave única
    private Set<String> registroDNI = new HashSet<>(); //Set para llevar los DNI y manejar que no se repitan
    private static int contadorId = 0;

    //Añadir una persona
    public void añadirPersona() {
        while (true) {
            System.out.println("Dime el DNI de la persona o escribe 'salir' para finalizar la operación:");
            String edni = entrada.nextLine();

            if ("salir".equalsIgnoreCase(edni)) {
                System.out.println("Operación finalizada.");
                break;
            }

            if (!verificarDNI(edni)) {
                System.out.println("Error: DNI inválido. Debe contener 8 dígitos seguidos de una letra.");
                continue;
            }

            if (registroDNI.contains(edni)) {
                System.out.println("Error: DNI ya registrado.");
                continue;
            }

            System.out.println("Ingrese el primer apellido (Máximo 40 caracteres):");
            String eapellido1 = entrada.nextLine();
            System.out.println("Ingrese el segundo apellido (Máximo 40 caracteres):");
            String eapellido2 = entrada.nextLine();
            System.out.println("Ingrese el nombre (Máximo 20 caracteres):");
            String enombre = entrada.nextLine();
            System.out.println("Ingrese la dirección (Máximo 225 caracteres):");
            String edireccion = entrada.nextLine();

            try {
                Persona nuevaPersona = new Persona(++contadorId, edni, eapellido1, eapellido2, enombre, edireccion);
                personas.put(contadorId, nuevaPersona);
                registroDNI.add(edni);  
                System.out.println("Persona añadida, su ID es " + nuevaPersona.getId());
                break;  
            } catch (IllegalArgumentException e) {
                System.out.println("Error al crear la persona: " + e.getMessage());
                //Si hay un error restamos el contador ya que no se a creado la persona
                contadorId--;
            }
        }
    }

    //Mostrar persona por ID
    public void mostrarPersona() {
        while (true) {
            System.out.println("Dime el ID de la persona que quieres buscar o escribe 'salir' para finalizar la operación:");

            // Asegurarse de que la entrada siguiente sea correcta
            if (!entrada.hasNextInt()) { //si la entrada no es un int se guarda la respuesta y se comprueba si es "salir", si lo es se finaliza el bucle, si no, vuelve a preguntar
                String respuesta = entrada.next();
                if ("salir".equalsIgnoreCase(respuesta)) {
                    System.out.println("Operación finalizada.");
                    break;
                } else {
                    System.out.println("Entrada inválida, por favor introduce un número de ID válido o 'salir' para terminar.");
                    continue;
                }
            }

            int eid = entrada.nextInt();//si es un int, se guarda como el id, y se comprueba si se corresponde con alguna persona registrada, si no, vuelve a preguntar.
            if (personas.containsKey(eid)) {
                Persona persona = personas.get(eid);
                System.out.println("La persona con el ID " + eid + " es: " + persona.toString());
                // Si deseas que el bucle termine después de encontrar una persona, descomenta la siguiente línea:
                // break;
            } else {
                System.out.println("El ID introducido no corresponde a ninguna persona, intentélo de nuevo o escriba 'salir' para finalizar la operación.");
            }
        }
    }

    //Borrar Persona
    public void borrarPersona() {
        while (true) {
            System.out.println("Dime el ID de la persona que desea borrar");
            if (!entrada.hasNextInt()) {
                String respuesta = entrada.next();
                if ("salir".equalsIgnoreCase(respuesta)) {
                    System.out.println("Operación finalizada.");
                    break;
                } else {
                    System.out.println("Entrada inválida, por favor introduce un número de ID válido o 'salir' para terminar.");
                    continue;
                }
            }
            int eid = entrada.nextInt();
            if (personas.containsKey(eid)) {
                Persona persona = personas.get(eid);
                personas.remove(eid);
                System.out.println("La persona: " + persona.toString() + " a sido eliminada.");
                break;
            } else {
                System.out.println("El ID introducido no corresponde a ninguna persona, intentélo de nuevo o escriba 'salir' para finalizar la operación.");
            }
        }
    }

    //Mostrar personas por orden alfabetico
    public void mostrarPersonasOrdenadasPorApellido() {
        List<Persona> listaPersonas = new ArrayList<>(personas.values());
        Collections.sort(listaPersonas, (Persona p1, Persona p2) -> p1.getApellido1().compareTo(p2.getApellido1()));
        if (listaPersonas.isEmpty()) {
            System.out.println("No hay personas registradas.");
        } else {
            System.out.println("Personas ordenadas por apellido:");
            for (Persona persona : listaPersonas) {
                System.out.println(persona);
            }
        }
    }

    //Metodo para mostrar el ID de una persona segun su DNI
    public void mostrarID() {
        while (true) {
            System.out.println("Dime el DNI de la persona de la que quieres saber el ID");
            String edni = entrada.nextLine();
            if (!verificarDNI(edni)) {
                System.out.println("Error: DNI inválido. Debe contener 8 dígitos seguidos de una letra.");
                continue;
            }
            if (!personas.containsKey(edni)) {
                System.out.println("El DNI introducido no corresponde a ninguna persona ");
                continue;
            } else {
                Persona persona = personas.get(edni);
                System.out.println("Estos son los datos de la persona con DNI:" + edni.toString() + " " + persona.toString());
            }

        }
    }

    //Guardar personas en un archivo
    public void guardarDatos() throws IOException {

        try (ObjectOutputStream escritura = new ObjectOutputStream(new FileOutputStream("personas.dat"))) {
            escritura.writeObject(personas);
            escritura.writeInt(contadorId);  // Guarda el próximo ID disponible
        }
    }

    //Cargar el map de personas de un archivo
    public void cargarDatos() {
        File archivo = new File("personas.dat");
        if (!archivo.exists()) {
            personas = new HashMap<>();  // Inicializar si el archivo no existe
            contadorId = 1;  // Reinicia el contador de ID si no hay datos
            System.out.println("Archivo de datos no encontrado. Se ha inicializado un nuevo registro.");
            return; // Salir del método si no hay archivo
        }

        try (ObjectInputStream lectura = new ObjectInputStream(new FileInputStream(archivo))) {
            personas = (HashMap<Integer, Persona>) lectura.readObject();
            contadorId = lectura.readInt();  // Carga el ID que sigue
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error al cargar los datos: " + e.getMessage());
            personas = new HashMap<>();  // Inicializar en caso de error de lectura
            contadorId = 1;  // Reinicia el contador de ID
        }
    }

    //Verificación de el DNI
    public static boolean verificarDNI(String dni) {
        // Expresión regular que comprueba 8 dígitos seguidos de una letra
        String expresion = "\\d{8}[A-Za-z]";

        // Comprobar si el dni es null o no coincide con la expresión regular
        if (dni == null || !dni.matches(expresion)) {
            return false;
        }
        return true;
    }
}
