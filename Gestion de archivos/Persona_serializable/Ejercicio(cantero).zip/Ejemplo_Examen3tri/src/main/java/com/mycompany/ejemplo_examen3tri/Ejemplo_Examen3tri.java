/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.ejemplo_examen3tri;

import java.io.IOException;
import java.util.*;

/**
 *
 * @author Miguel Cantero
 */
public class Ejemplo_Examen3tri {
    static Scanner  entrada = new Scanner(System.in);
    static Gestor_Personas gestion = new Gestor_Personas();

    public static void main(String[] args) throws IOException, ClassNotFoundException {       
        gestion.cargarDatos();
        menu();
        gestion.guardarDatos();
    }
        //Menú
        public static void menu() {       
        Boolean salir = true;
        int opcion;

        while (salir) {
            System.out.println("Introduce 1 para añadir una persona");
            System.out.println("Introduce 2 para mostrar una persona según su ID");
            System.out.println("Introduce 3 para borrar una persona según su ID");
            System.out.println("Introduce 4 mostrar todas las personas por orden alfabético");
            System.out.println("Introduce 5 para recordar los datos de una persona según su dni");
            System.out.println("Introduce 6 para salir");
            opcion = entrada.nextInt();

            switch (opcion) {
                case 1:
                    gestion.añadirPersona();
                    break;
                case 2:
                    gestion.mostrarPersona();
                    break;
                case 3:
                    gestion.borrarPersona();
                    break;
                case 4:
                    gestion.mostrarPersonasOrdenadasPorApellido();
                    break;
                case 5:
                    gestion.mostrarID();
                case 6:
                    salir = false;
                    break;
                default:
                    System.out.println("Debes elegir una opción correcta");
            }
        }
    }
}
