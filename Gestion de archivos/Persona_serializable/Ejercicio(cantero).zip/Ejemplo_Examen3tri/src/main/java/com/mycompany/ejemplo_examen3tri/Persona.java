/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejemplo_examen3tri;

import java.io.Serializable;

/**
 *
 * @author migue
 */
public class Persona implements Serializable{
    private static final long serialVersionUID = 1L;    
    private int id;
    private String dni;
    private String apellido1;
    private String apellido2;
    private String nombre;
    private String direccion;
    
    //Constructor por defecto

    public Persona() {
        this.id = 0;
        this.dni="";
        this.apellido1="";
        this.apellido2="";    
        this.nombre="";
        this.direccion="";
    }
    
    //Constructor parametrizado

    public Persona(int id, String dni, String apellido1, String apellido2, String nombre, String direccion) {
        this.id = id;
        this.dni = dni;
        if (apellido1.length() > 40) {
            throw new IllegalArgumentException("Los apellidos solo pueden contener 40 caracteres");
        }
        this.apellido1 = apellido1;
        
        if (apellido2.length() > 40) {
            throw new IllegalArgumentException("Los apellidos solo pueden contener 40 caracteres");
        }
        this.apellido2 = apellido2;
        
        if (nombre.length() > 20) {
            throw new IllegalArgumentException("El nombre solo puede tener 20 caracteres");
        }
        this.nombre= nombre;
        
        if (direccion.length() > 225) {
            throw new IllegalArgumentException("La dirección solo puede tener 225 caracteres");
        }
        this.direccion = direccion;
    }
    
    //Constructor de copia
    
    public Persona (Persona c){
        this.id = c.id;
        this.dni = c.dni;
        this.apellido1 = c.apellido1;
        this.apellido2 = c.apellido2;
        this.nombre = c.nombre;
        this.direccion = c.direccion;
    }
    
    //Getter y Setter

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getApellido1() {
        return apellido1;
    }

    public void setApellido1(String apellido1) {
        if (apellido1.length() > 40) {
            throw new IllegalArgumentException("Los apellidos solo pueden contener 40 caracteres");
        }
        this.apellido1 = apellido1;
    }

    public String getApellido2() {
        return apellido2;
    }

    public void setApellido2(String apellido2) {
        if (apellido2.length() > 40) {
            throw new IllegalArgumentException("Los apellidos solo pueden contener 40 caracteres");
        }
        this.apellido2 = apellido2;
    }
    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        if (nombre.length() > 20) {
            throw new IllegalArgumentException("El nombre solo puede tener 20 caracteres");
        }       
        this.direccion = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
         if (direccion.length() > 225) {
            throw new IllegalArgumentException("La dirección solo puede tener 225 caracteres");
        }       
        this.direccion = direccion;
    }

    
    //ToString
    @Override
    public String toString() {
        return "Persona{" + "id=" + id + ", dni=" + dni + ", apellido1=" + apellido1 + ", apellido2=" + apellido2 + ", nombre=" + nombre + ", direccion=" + direccion + '}';
    }
    
}

